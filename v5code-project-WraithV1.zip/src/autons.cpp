#include "vex.h"

void default_constants() {
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(10, 1.5, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form of (settle_error, settle_time,
  // timeout).
  chassis.set_drive_exit_conditions(1.5, 300, 3000);
  chassis.set_turn_exit_conditions(1, 300, 3000);
  chassis.set_swing_exit_conditions(1, 300, 3000);
}

void Elim_constants() {
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(10, 1.5, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form of (settle_error, settle_time,
  // timeout).
  chassis.set_drive_exit_conditions(1.5, 150, 1000);
  chassis.set_turn_exit_conditions(1, 150, 1000);
  chassis.set_swing_exit_conditions(1, 200, 1000);
}

// void CloseSide_constants(){
//   // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
//   chassis.set_drive_constants(12, 1.5, 0, 10, 0);
//   chassis.set_heading_constants(12, .4, 0, 1, 0);
//   chassis.set_turn_constants(12, .4, .03, 3, 15);
//   chassis.set_swing_constants(12, .3, .001, 2, 15);

//   // Each exit condition set is in the form (settle_error, settle_time,
//   timeout). chassis.set_drive_exit_conditions(1.5, 200, 500);
//   chassis.set_turn_exit_conditions(1, 200, 500);
//   chassis.set_swing_exit_conditions(1, 200, 500);
// }

//.set_coordinates works as X coordinate, Y coordinate, orientation (In degrees,
//360 degree format)
void TestDrive(){

}

void No_Auton() {
  chassis.drive_max_voltage = 12;
  default_constants();
  chassis.set_coordinates(0, 0, 25);
  wait(0.2, sec);
  chassis.drive_distance(5);
}

void Red_RHS_S2() {
  default_constants();
}

void Red_LHS_S2() {
  default_constants();
}

void Red_LHS(){
  Elim_constants();
}

void Red_Elim() {
    Elim_constants();
}

void Blue_LHS() {
  default_constants();
}

void Blue_RHS() {
  default_constants();
}

void Blue_RHS_S2() {
  default_constants();
}

void Blue_LHS_S2() {
  default_constants();
}

void Blue_Elim() {
  Elim_constants();
}

void RedAWP() {
  default_constants();
}
void BlueAWP() {
  default_constants();
}
void Skill_Auton() {
}