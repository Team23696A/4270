#include "globals.h"
int current_auton_selection = 0;
//int a = 0;
int ScreenPage = 0;
bool auto_started = false;

std::string autonSelected = "No Auton";
int LeftM1Temp = 0;
int LeftM2Temp = 0;
int LeftM3Temp = 0;
int RightM1Temp = 0;
int RightM2Temp = 0;
int RightM3Temp = 0;

bool ToggleTempDisplay = false;
int a = 10;
bool AJ = false;
bool IntakeTop = false;
bool IntakeMid = false;
bool IntakeLow = false;
bool Stopper = false;
bool intakeStatus = false;
int avgDriveTrainTemp = 0;

