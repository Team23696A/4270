using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern inertial InertialSensor;
extern motor RightM1;
extern motor RightM2;
extern motor RightM3;
extern motor LeftM1;
extern motor LeftM2;
extern motor LeftM3;
extern motor Intake1;
extern motor Intake2;
extern digital_out Intake;
extern digital_out Claw;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );