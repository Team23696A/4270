#include <string>
//Screen 1 (Home Page)
void drawLogo();
void Start_Screen();
void drawRed();
void drawBlue();
void drawPID();

//Screen 2 (Auton Selection)
void AutonomousSelection();
void Red_Auton_Screen();
void Blue_Auton_Screen();

//Robot Stats
void DeviceInfoScreen();

//debug screen (not operational yet)
void DebugScreen();

//screen clicking detection system
void BrainClickedIndicator();

//variable for 
extern int ScreenPage;

extern int LeftM1Temp;
extern int LeftM2Temp;
extern int LeftM3Temp;
extern int RightM1Temp;
extern int RightM2Temp;
extern int RightM3Temp;
extern bool ToggleTempDisplay;

//Average Temperture calc
extern int a;
void displayAvgTemp();

//Autons
extern bool auto_started;
void Blue_LHS();
void Blue_RHS();
void Blue_RHS_S2();
void Blue_LHS_S2();
void Red_LHS();
void Red_RHS();
void Red_RHS_S2();
void Red_LHS_S2();
void RedAWP();
void BlueAWP();
void Blue_Elim();
void Red_Elim();
void Skill_Auton();
void No_Auton();
void default_constants();
void Elim_constants();
//Debug
void DrivetrainTest();
void IntakeTest();
void BatteryStatusScreen();
void ScreenTest();
void PneumaticsTest();
void ToggleTest();
void TestDrive();

//auton selection
extern std::string autonSelected;
extern int current_auton_selection;

//intake toggles
extern int a;
extern bool AJ;
extern bool IntakeTop;
extern bool IntakeMid;
extern bool IntakeLow;
extern bool Stopper;
extern bool intakeStatus;
extern int avgDriveTrainTemp;

void updateIntake();